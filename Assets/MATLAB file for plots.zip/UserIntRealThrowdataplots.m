% Test Subject 1

x10 = [-5 5 1 -8 1];
y10 = [-5 5 7 -5 1];

x15 = [0 5 -1 11 2];
y15 = [10 -2 1 10 7];

x20 = [11 -2 -6 -6 -9];
y20 = [8 6 4 8 -4];

x25 = [-11 -5 -4 -8 NaN];
y25 = [-1 0 -9 -9 NaN];

figure('Name','Test Subject 1')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 1');
legend('10 ft','15 ft','20 ft','25 ft')


% Test Subject 2

x10 = [-8 2 -4 3 -5];
y10 = [0 -1 3 4 -1];
 
x15 = [1 -12 -9 0 -11];
y15 = [4 -3 11 0 -12];
 
x20 = [NaN 3 6 NaN NaN];
y20 = [NaN -6 -5 NaN NaN];
 
x25 = [2 NaN NaN NaN 11];
y25 = [-4 NaN NaN NaN 9];

figure('Name','Test Subject 2')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 2');
legend('10 ft','15 ft','20 ft','25 ft')


% Test Subject 3

x10 = [-3 -12 -5 8 7];
y10 = [3 6 5 2 -3];
 
x15 = [-8 -2 1 10 NaN];
y15 = [-11 -2 1 10 NaN];
 
x20 = [NaN 6 NaN -11 -6];
y20 = [NaN -6 NaN -4 -6];
 
x25 = [NaN NaN 7 -6 NaN];
y25 = [NaN NaN -1 -8 NaN];

figure('Name','Test Subject 3')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 3');
legend('10 ft','15 ft','20 ft','25 ft')


% Test Subject 4

x10 = [-9 -2 1 -1 0];
y10 = [4 3 2 9 6];
 
x15 = [8 3 NaN -4 -6];
y15 = [2 6 NaN -7 -6];
 
x20 = [-11 NaN 5 6 NaN];
y20 = [-6 NaN 2 1 NaN];
 
x25 = [-2 NaN -3 1 7];
y25 = [9 NaN -8 1 8];

figure('Name','Test Subject 4')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 4');
legend('10 ft','15 ft','20 ft','25 ft')


% Test Subject 5

x10 = [7 7 10 -4 -11];
y10 = [0 1 2 6 4];
 
x15 = [NaN NaN 7 -2 -4];
y15 = [NaN NaN -3 -2 0];
 
x20 = [2 NaN NaN NaN NaN];
y20 = [9 NaN NaN NaN NaN];
 
x25 = [NaN NaN 6 NaN 11];
y25 = [NaN NaN 0 NaN -6];

figure('Name','Test Subject 5')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 5');
legend('10 ft','15 ft','20 ft','25 ft')


% Test Subject 6

x10 = [-7 NaN -6 NaN NaN];
y10 = [9 NaN 7 NaN NaN];
 
x15 = [NaN NaN 7 -2 NaN];
y15 = [NaN NaN -3 -2 NaN];
 
x20 = [NaN -9 0 NaN NaN];
y20 = [NaN 3 10 NaN NaN];
 
x25 = [NaN NaN NaN NaN NaN];
y25 = [NaN NaN NaN NaN NaN];

figure('Name','Test Subject 6')
plot(x10,y10,'x' , x15,y15,'^' , x20,y20,'*' , x25,y25,'d')
graphProperties('Test Subject 6');
legend('10 ft','15 ft','20 ft','25 ft')





function graphProperties(name)
title(name)
axis([-12 12 -12 12])

% Draw in the X and Y axis
line(xlim, [0,0], 'Color', 'k', 'LineWidth', 1);
line([0,0], ylim, 'Color', 'k', 'LineWidth', 1);

xlabel('X direction [in]')
ylabel('Y direction [in]')

grid on
grid minor

end

